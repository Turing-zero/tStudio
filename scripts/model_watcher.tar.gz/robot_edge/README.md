# Robot Edge Model Watcher

该工具运行在植树机器人的边缘侧工控机上，负责监听 URDF/STL 文件的变更，并自动打包推送到云端调度系统，实现数字孪生模型的“热更新”。

## 1. 环境要求

- **OS**: Linux (Ubuntu 20.04/22.04 推荐) 或 Windows (测试环境)
- **Python**: 3.8+
- **网络**: 需能访问调度服务器的 HTTP 接口 (默认 8000 端口)

## 2. 安装部署

### 2.0 传输文件 (关键步骤)

**注意**：你**不需要**拷贝整个项目或 `backend` 目录。仅需将 `scripts/robot_edge` 文件夹拷贝到机器人即可。

**方法 A：使用 SCP (推荐)**
在你的开发机（Windows/Mac）上运行：
```bash
# 假设机器人 IP 为 10.144.144.2，用户名为 david (或者是 root)
# 将本地的 robot_edge 目录拷贝到机器人的 home 目录并重命名为 model_watcher
scp -r scripts/robot_edge david@10.144.144.2:~/model_watcher
```

**方法 B：使用 U 盘**
将 `scripts/robot_edge` 文件夹复制到 U 盘，插入机器人工控机，拷贝到 `~/model_watcher`。

**方法 C：使用 SFTP (打包上传)**
由于标准 SFTP 命令行不支持直接上传文件夹，建议先打包再上传：

1. **本地打包 (在开发机)**
   ```bash
   # 进入脚本目录
   cd scripts
   # 将 robot_edge 文件夹压缩为 model_watcher.zip
   # (Windows 用户可右键文件夹 -> 发送 -> 压缩文件夹)
   tar -czvf model_watcher.tar.gz robot_edge
   ```

2. **上传文件**
   ```bash
   sftp david@10.144.144.2
   sftp> put model_watcher.tar.gz
   ```

3. **机器人端解压**
   ```bash
   ssh david@10.144.144.2
   # 解压并重命名
   tar -xzvf model_watcher.tar.gz
   mv robot_edge model_watcher
   cd model_watcher
   ```

### 2.1 安装依赖

SSH 登录到机器人，进入刚才拷贝的目录，创建虚拟环境并安装依赖：

```bash
ssh david@10.144.144.2
cd ~/model_watcher

# 创建并激活虚拟环境
python3 -m venv venv
source venv/bin/activate

# 安装依赖 (仅需 requests 和 watchdog)
pip install -r requirements.txt
```

### 2.2 运行测试

假设你的机器人描述包位于 `~/ros2_ws/src/tree_robot_description`，服务器 IP 为 `10.144.144.2`。

运行以下命令启动监听：

```bash
python watcher.py \
  --dir ~/ros2_ws/src/tree_robot_description \
  --url http://10.144.144.2:8000/api/model/upload-zip \
  --type tree_planter
```

启动后，当你修改该目录下的任意 `.urdf` 或 `.stl` 文件并保存时，脚本会在 2 秒后自动触发打包上传。

## 3. 生产环境部署 (Systemd)

在 Linux 生产环境中，建议将其配置为 Systemd 服务实现开机自启。

1. 修改并创建服务文件 `/etc/systemd/system/model-watcher.service`:

```ini
[Unit]
Description=Robot Model Auto-Sync Watcher
After=network.target

[Service]
Type=simple
User=david
WorkingDirectory=/home/david/tStudio/scripts/robot_edge
# 请修改下方的路径和参数
ExecStart=/home/david/tStudio/scripts/robot_edge/venv/bin/python watcher.py \
    --dir /home/david/ros2_ws/src/tree_robot_description \
    --url http://10.144.144.2:8000/api/model/upload-zip \
    --type tree_planter
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

2. 启用并启动服务：

```bash
sudo systemctl daemon-reload
sudo systemctl enable model-watcher
sudo systemctl start model-watcher
```

3. 查看日志：

```bash
sudo journalctl -u model-watcher -f
```

## 4. 模拟测试方法

如果你没有物理机器人，可以在本地模拟：

1. 创建一个测试目录：
   ```bash
   mkdir -p temp_robot_desc/urdf
   echo "<robot name='test'></robot>" > temp_robot_desc/urdf/robot.urdf
   ```

2. 启动 watcher (假设服务器在 localhost):
   ```bash
   python watcher.py --dir ./temp_robot_desc
   ```

3. 修改文件触发上传：
   ```bash
   echo "<!-- modified -->" >> temp_robot_desc/urdf/robot.urdf
   ```

4. 观察控制台输出，应显示 `Detected change` -> `Debounce finished` -> `Upload SUCCESS`。
